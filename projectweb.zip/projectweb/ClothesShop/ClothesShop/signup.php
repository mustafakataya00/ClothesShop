<?php 

include("C:\wamp64\www\php22\ClothesShop\usermanager.php");  

if(isset($_POST)) 
{   
    $username=$_POST['username'];
    $phone_num=$_POST['phonenumber'];
    $email=$_POST['email'];
    $pass=$_POST['password'];

    $pass1 = md5($pass);
	//Add Additional security using sha1 hash of the password
	$pass2 = sha1($pass1);
	//Add encryption with salt
	$salt = "abcd";
	//Apply the encryption
	$pass3 = crypt($pass2,$salt);
	//Add more complexity to the encryption
	$pass4 = $pass3.$pass2;

    $result = Signup($username,$pass4,$email,$phone_num);

        if($result) { 
            echo "<script type='text/javascript'
            alert('User Created!'); 
            window.location.replace('signin.php') 
            </script>"; 
        } 
        else { 
            echo "<script language=javascript'> 
            alert('Username already in use. Please choose another one!'); 
            window.location.replace('registre.php') 
            </script>"; 
    } 
   }



?>

 
    