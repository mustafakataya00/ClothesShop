<?php

include "config.php";

if(isset($_POST['submit'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $level = $_POST['Level'];
    $Phone_num = $_POST['Phone_num'];
    $sql = "INSERT INTO users (username, password, email, Level, Phone_num) VALUES ('$username', '$password', '$email', '$level', '$Phone_num')";
    $result = $con->query($sql);
    if($result) {
        header('Location: view.php');
    } else {
        echo "Error: " . $stmt->error;
    }

    $con->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Add User</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

   <link rel="stylesheet" href="styleview.css"> 
  <link rel="stylesheet" href="stylecr.css">
  
  

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!-- <a class="navbar-brand" href="#">Navbar</a> -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="view.php">Home <span class="sr-only"></span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="signin.php">Goto Website</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="create.php">Add User</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="createproduct.php">Add Product</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="viewproducts.php">view products</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Logout</a>
      </li>
    </ul>
  </div>
</nav>
<form action="" method="POST">
   <fieldset>
    <legend> Personal Information: </legend>
   Username: <br>
    <input type="text" name="username">
    <br>
    Password: <br>
    <input type="password" name="password">
    <br>
    Email: <br>
    <input type="email" name="email">
    <br>
   Level <br>
    <input type="radio" name="Level" value= "1">1
    <input type="radio" name="Level" value= "0">0
    <br><br>
    Phone Number: <br>
    <input type="tel" name="Phone_num">
    <br>
    
   
    <input type="submit" name="submit" value="Submit">
   </fieldset>
</form>

</body>
</html>

<?php


