<?php
    if(session_status() == PHP_SESSION_NONE){
        session_start();
    }  
                 require_once('connection.php');
                 $email = $_POST['email0'];
                 $sql="insert into newsLetter(email) values ('$email')";
                 $result=mysqli_query($con,$sql);
if($result)
{ 
    if(isset($_SESSION["wp20user"]))
    { 
    header("Location:user.php");
    } 
    else if(isset($_SESSION["wp20admin"]))
    { 
        header("Location:admin.php");
    } 
}
else
{
    echo "<script type='text/javascript'> 
alert('Cannot Register Your email ');
</script>";
}

                 
?>