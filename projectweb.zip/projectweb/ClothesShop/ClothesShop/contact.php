
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BestInTown</title>
    <script src="https://kit.fontawesome.com/e54aa46220.js" ></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
        <section id="header">
            
        <a href="user.php"><img src="img/logoBest.png" style="width:90px;height:70px"  class="logo" alt=""> </a>            
            <div>
                <ul id="navbar">
                    <li><a href="user.php">Home</a></li>
                    <li><a href="shop.php">Shop</a></li>
                    <li><a href="blog.php">Blog</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a class="active" href="contact.php">Contact</a></li>
                    <?php         
      if(session_status() == PHP_SESSION_NONE){
        //session has not started
        session_start();
    }
    if(isset($_SESSION["wp20user"]))
    { 
    echo '<li><a href="cart.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
    echo' <li><a href="signout.php">Logout</a></li>' ;
    } 
    else 
    { 
   echo '<li><a href="signin.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
   echo '<li><a href="signin.php" ><i class="fa-solid fa-user"></i></a></li>' ;
    } 
?>
                </ul>
            </div>
          

        </section>

        <section id="page-header" class="about-header">
            
            <h2>#Let's_Talk</h2>
            
            <p>Leave A Message , We love to hear from You!</p>
        </section>

        <section id="contact-details" class="section-p1">
            <div class="details">
                <span>GET IN TOUCH</span>
                <h1>Visit one of our agency today</h1>
                <h3>Head office</h3>
                <div>
                    <li>
                        <i class="fa fa-map"></i>
                        <p>Beirut-Lebanon Camil Chamoun Street</p>
                    </li>
                    <li>
                        <i class="fa fa-envelope"></i>
                        <p>Support_BestInTown@gmail.com</p>
                    </li>
                    <li>
                      <i class="fa fa-phone-alt"></i>
                        <p>+961 76 935 846 - +961 76 779 380</p>
                    </li>
                    <li>
                        <i class="fa fa-clock"></i>
                        <p> 10:00 am - 10:00 pm ... Mon - Sat </p>
                    </li>
                </div>
            </div>

            <div class="map" >
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13430.223463617102!2d35.534300114485085!3d33.83290772075906!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151f1826928eeb3d%3A0xfd356d0625e311ab!2sAntonine%20University%20(UA)!5e0!3m2!1sen!2slb!4v1669904004602!5m2!1sen!2slb"
                 width="600" height="450" style="border:0;" 
                 allowfullscreen="" loading="lazy" 
                 referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

        </section>

        <section id="foo" class="form-details" >

            <form id="from" style="height:600px;" method="post">
                <span>LEAVE A MESSAGE</span>
                <h2>We love to hear from you</h2>
                <input type="text" name = "name" placeholder="UserName">
                <input type="email" name="email" placeholder="E-mail">
                <input type="text" name="mobileNumber" placeholder="Phone Number" >
                <input type="text" name="Title" placeholder="Title" >
                <textarea name="subject" rows="4" cols="50" placeholder="Enter Your Message" style="padding: 10px;resize: none;"></textarea>
                <input type="submit" class="normal" name="send" value="Submit" style="background-color:blue;color:white;">
                
            </form>

            <div class="people">
                <?php
                    require_once("connection.php");

                    $sql = "Select * from Employees";
                    $res = mysqli_query($con , $sql);
                   while($row = mysqli_fetch_array($res))
                   {
                        $name = $row['Name'];
                        $role = $row['Role'];
                        $phone = $row['Phone']; 
                        $email = $row['Email'];   
                        $img = $row['img_path'];                

                        echo "<div>
                        <img src=$img>
                        <p><span>$name</span> $role <br> Phone:$phone <br> Email:$email</p>
                   </div>";
                   }
                   
                   if(isset($_POST['send']))
                    {

                    $name0 = $_POST["name"];
                    $email0 = $_POST["email"];
                    $phonenumber = $_POST["mobileNumber"];
                    $title = $_POST["Title"];
                    $subject = $_POST["subject"];

                        $query = "Insert into messages(username,email,Phone_Number,Title,Message) values('$name0','$email0','$phonenumber','$title','$subject')";
                        $run = mysqli_query($con,$query);

                    
                        if($run)
                        {
                            echo "<script type='text/javascript'> 
                            alert('Message Received , ThankYou for your Visit!');
                        </script>"; 
                        }
                        else{
                            echo "<script type='text/javascript'> 
                            alert('Failed');
                        </script>"; 
                            
                        }
                    
                    
                    }
                   ?>

            </div>
        </section>
        
        <section id="newsletter" class="section-p1 section-m1">
            <div class="newstext">
                 <h4>Sign Up For Newsletters</h4>
                 <p>GetE-mail updates about our latest shop and<span> special offers.</span>
                 </p>
            </div>
            <form method="post" action='addEmailUpdates.php' style="width : 500px; height:20px;" class="form" >

<input type="email" name="email0" placeholder="Your email address">
<button  class="normal">Sign Up</button>

</form>
        </section>

        <footer class="section-p1">
            <div class="col">
    
                <p><strong>Address: </strong> Hadath,Near Consultation Council,Baabda </p>
                <p><strong>Phone: </strong> +961-76-935-846 / 05-464-073 </p>
                <p><strong>Working hours: </strong> 10:00 am - 10:00 pm,Mon - Sat  </p>
                <div class="follow">
                    <h4>Follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                    </div>
                </div>
            </div>
                 <div class="col1">
                    <a href="about.php">About us</a>
                    <a href="DeliveryPolicy.php">Delivery Information</a>
                    <a href="contact.php">Contact Us</a>
                </div>
                <div class="col2">
                    <h4>My Account</h4>
                    <a href="signin.php">Sign in</a>
                    <?php         
            if(session_status() == PHP_SESSION_NONE){
                //session has not started
                session_start();
            }  
        if(isset($_SESSION["wp20user"]))
        { 
         echo '<a href="cart.php">View Cart</a>';
        } 
        else 
        { 
          echo '<a href="signin.php">View Cart</a>';
        } 
    ?>
                </div>
                
                <div class="col install">
                    <h4>Install App</h4>
                    <p>From AppStore or GooglePlay</p>
                    <div class="row">
                    <a href="https://apps.apple.com/today" ><img src="img/pay/app.jpg" alt=""></a>
                        <a href= "https://play.google.com/store/apps" ><img src="img/pay/play.jpg" alt=""></a>
                    </div>
                    <p>Secured Payements Gateways</p>
                    <img src="img/pay/pay.png" alt="">
                </div>
                
                <div class="copyright">
                <p>&copy; 2022 BestInTown | All Rights Reserved </p>
                </div>
        </footer>

    <script src="script.js"> </script>
</body>
</html>   