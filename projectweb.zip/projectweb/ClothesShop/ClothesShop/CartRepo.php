
 <?php
 require('connection.php');
 
 //inserting a user in the database
  function InsertCart($id_product,$username,$size,$quantity)
 { 
    require('connection.php');
    $res = false;
    $stmt = $con->prepare("insert into cart (username, product_ID,size,Quantity) values(?,?,?,?)");
     $stmt->bind_param("sisi",$username,$id_product,$size,$quantity);
     $stmt->execute();
     $stmt->close();
     $res=true;
     
     return $res;
 }
 
     
     
 
 
  function Get($username){ 
    require('connection.php');

        $sql ="select * from cart Where user_ID='". $username."' ;";
        $result= mysqli_query($con, $sql);
      
        
            return $result;

 }

 function GetOne($ID_Product){ 
    require('connection.php');
        $sql ="Select * from products Where product_ID =$Id_Product";
        $result= mysqli_query($con, $sql);
      
        return $result;
           }

 function RemoveAlbum($Id_Product){ 
    require('connection.php');
        $sql ="Delete from cart Where product_ID='".$Id_Product."'and username ='".$_SESSION['wp20user']."'";
        $result= mysqli_query($con, $sql);
      
            if($result==false)
            {return false;}

           return true;
           }
?>
