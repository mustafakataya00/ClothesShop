<?php
include "config.php";
$sql = "SELECT * from users";
$result = $con->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width='device-width', initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="styleview.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"> 
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!-- <a class="navbar-brand" href="#">Navbar</a> -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="signin.php">Goto Website</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="create.php">Add User</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="createproduct.php">Add Product</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="viewproducts.php">view products</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Logout</a>
      </li>
    </ul>
  </div>
</nav>

    <div class="container">
        <h2>users</h2>
        <table class="table" >
            <tr>
                <th>Id</th>
                <th>Firstname</th>
                <th>Lastname</th>
                <th>Email</th>
                <th>gender</th>
                <th>Phone Number</th>
                <th>Action</th>
            </tr>
</thread>
        </tbody>

    <?php
    if($result->num_rows>0){
        while($row=$result->fetch_assoc()){
    ?>
    <tr>
<td><?php echo $row['id']; ?> </td>
<td><?php echo $row['username']; ?> </td>
<td><?php echo $row['password']; ?> </td>
<td><?php echo $row['email']; ?> </td>
<td><?php echo $row['Level']; ?> </td>
<td><?php echo $row['Phone_num']; ?> </td>

<td><a class="btn btn-info" href="update.php?id=<?php echo $row['id']; ?>">
Edit</a>&nbsp;<a class="btn btn-danger" href="delete.php?id=<?php echo $row['id']; ?>">
Delete</a></td>

     </tr>
<?php
        }
         }
         ?>
</tbody>
</table>

</body>
</html>