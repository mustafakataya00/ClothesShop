<?php

// Disable error reporting
error_reporting(0);

// Disable display of errors
ini_set('display_errors', 'Off');

// Your PHP code goes here

?>


<?php

include "config.php";

// Initialize variables to empty strings
$username = '';
$id = '';
$password = '';
$email = '';
$level = '';
$Phone_num = '';

if(isset($_POST['update'])) {
    $username = $_POST['username'];
    $id = $_POST['id'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $level = (int)$_POST['Level'];
    $Phone_num = $_POST['Phone_num'];

    $stmt = $con->prepare("UPDATE users SET username=?, password=?, email=?, level=?, Phone_num=? WHERE id=?");
    $stmt->bind_param("sssisi", $username, $password, $email, $level, $Phone_num, $id);
    $result = $stmt->execute();

    if($result) {
        header('Location: view.php');
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

if(isset($_GET['id'])) {
    $user_id = $_GET['id'];

    $stmt = $con->prepare("SELECT * FROM users WHERE id=?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $username = $row['username'];
            $password = $row['password'];
            $email = $row['email'];
            $level = $row['Level'];
            $Phone_num = $row['Phone_num'];
            $id = $row['id'];
        }
    }

    $stmt->close();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
  <link rel="stylesheet" href="stylee.css">


</head>
<body>
<h2>User update form</h2>
<form action="" method="post">
    <fieldset>
        <legend>Personal infos</legend>
        Username:<br>
        <input type="text" name="username" value="<?php echo isset($username) ? $username : '';?>">
        <input type="hidden" name="id" value="<?php echo isset($id) ? $id : '';?>">
        <br>
        Password:<br>
        <input type="password" name="password" value="<?php echo isset($password) ? $password : '';?>">
        <br>
        Email:<br>
        <input type="email" name="email" value="<?php echo isset($email) ? $email : '';?>">
        <br>
        Level:<br>
        <input type="radio" name="level" value="1" <?php echo $level == 1 ? 'checked' : '';?>> Admin
        <input type="radio" name="level" value="0" <?php echo $level == 0 ? 'checked' : '';?>> Not Admin
        <br>
        Phone Number:<br>
        <input type="tel" name="Phone_num" value="<?php echo isset($Phone_num) ? $Phone_num : '';?>">
        <br>
        <br>
        <input type="submit" value="Update" name="update" onclick="window.location='view.php'">

    </fieldset>
    <?php
    
  


?>
</form>
</body>
</html>

