<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BestInTown</title>
    <script src="https://kit.fontawesome.com/e54aa46220.js" ></script>
</head>
<body>

<?php 
     if(session_status() == PHP_SESSION_NONE){
      //session has not started
      session_start();
  }
   require_once('connection.php');
   include_once('helpers.php');  
	$pageTitle = 'Demo PHP Shopping cart checkout page with Validation';
	$metaDesc = 'Demo PHP Shopping cart checkout page with Validation';
          
?>
 <section id="header">
            
            <a href="user.php"><img src="img/logoBest.png" style="width:90px;height:70px"  class="logo" alt=""> </a>            
                <div>
                    <ul id="navbar">
                        <li><a  href="user.php">Home</a></li>
                        <li><a href="shop.php">Shop</a></li>
                        <li><a  href="blog.php">Blog</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <?php         
            if(session_status() == PHP_SESSION_NONE){
                //session has not started
                session_start();
            }  
        if(isset($_SESSION["wp20user"]))
        { 
        echo '<li><a href="cart.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
        echo' <li><a href="signout.php">Logout</a></li>' ;
        } 
        else 
        { 
       echo '<li><a href="signin.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
       echo '<li><a href="signin.php" ><i class="fa-solid fa-user"></i></a></li>' ;
        } 
    ?>
                    </ul>
                </div>
              
    
            </section>
    
<div style ="margin-left:20px";>
        <div>
          <h4>
            <span >Your cart</span>

          </h4>
          <ul >
            <?php

                require_once('connection.php');
                $total = 0;
                $sql = "select * from cart where username ='".$_SESSION['wp20user']."'";
                $result=mysqli_query($con,$sql);

                while($row=mysqli_fetch_array($result))
                {
                  
                  $pid = $row['product_ID'];
                  $quantity = $row['Quantity'];
                  $size = $row['size'];

                  $sql2 = "select * from products where product_ID = $pid";
                  $result2 = mysqli_query($con,$sql2);

                  while($row1 = mysqli_fetch_array($result2))
                  {
                    $price = $row1['Price'];
                    $priceitems = $quantity*$price;
                    $total+=$priceitems;
                    
                    $desc = $row1['Description'];

                    echo "<li>
                        <div>
                            <h6 class='my-0'>$desc </h6>
                        </div>
                        <span>-Price : ".($price)."$ <br>-Quantity : ".($quantity)."<br>-ToTal : ".$priceitems."$ </span>
                    </li>";
                ?>
                    
            <?php
                }
              
                }
                if(isset($_POST['submit']))
                {
                            $Username = validate_input($_POST['username']);
                            $address = validate_input($_POST['address']);
                            $country = validate_input($_POST['country']);
                            $zipcode = validate_input($_POST['zipcode']);
                            $email = validate_input($_POST['email']);
            
                          $date = date('Y-m-d H:i:s');
                          $sql = "insert into order_details(username,email,address,Country,ZipCode,Total,created_at) values(?,?,?,?,?,?,?)";
                          $statement = $con->prepare($sql);
                          $statement->bind_param('sssssds', $Username,$email,$address,$country,$zipcode,$total,$date);
                          if($statement->execute())
                         {
                          header('Location:user.php?check=1');
                         }
                }
             
            ?>
           
            <li>
              
              <span>Total (USD)</span>
              <strong>$<?php echo number_format($total,2);?></strong>
            </li>
          </ul>
        </div>
      
                    <form method="post" action="checkout.php">
                    <h4 >Delivery & Checkout Form</h4>
                    <div >
              <label for="username" >Username</label>
              <input required type="text" id="username" name="username" placeholder="Username" value="">
            </div>

                
                    <div >
              <label for="email" >Email</label>
              <input required type="email"  id="email" name="email" placeholder="you@example.com" value="">
            </div>

            <div >
              <label for="address">Address</label>
              <input required type="text"  id="address" name="address" placeholder="1234 Main St" value="">
          </div>
          <div >
              <div >
                <label for="country">Country</label>
                <select required  name="country" id="country" >
                  <option value="">Choose...</option>
                  <option value="UAE" >UAE</option>
                  <option value="Lebanon" >Lebanon</option>
                  <option value="Turkey" >Turkey</option>
                  <option value="UK">UK</option>
                  <option value="Spain">Spain</option>
                  <option value="Germany">Germany</option>
                  <option value="Italy">Italy</option>
                  <option value="Egypt" >Egypt</option>
                  <option value="Syria" >Syria</option>
                  <option value="France" >France</option>
                  <option value="Russia" >Russia</option>
                  <option value="USA" >USA</option>
                </select>
              </div>
              <div >
                <label for="zip">Zip</label>
                <input required type="text" class="form-control" id="zip" name="zipcode" placeholder="" value=" ">
              </div>
            </div>

          <hr>
            <h4>Payment</h4>
            <div>
               <div>
                 <input id="cashOnDelivery" name="cashOnDelivery" type="radio" checked="" disabled >
                      <label  for="cashOnDelivery">Cash on Delivery</label>
                </div>
            </div>

          <hr> 
            <br>
               <div class="field button-field">
                  <input type="submit" name="submit" style="background-color : Blue ;color : white; width:300px;height:30px" id="submit" value="Proceed To CheckOut" >
                </div>
                                
      </div>
  </form>
</div>
</section>
</div>
<footer class="section-p1">
            <div class="col">
    
                <p><strong>Address: </strong> Hadath,Near Consultation Council,Baabda </p>
                <p><strong>Phone: </strong> +961-76-935-846 / 05-464-073 </p>
                <p><strong>Working hours: </strong> 10:00 am - 10:00 pm,Mon - Sat  </p>
                <div class="follow">
                    <h4>Follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                    </div>
                </div>
            </div>
                 <div class="col1">
                    <a href="about.php">About us</a>
                    <a href="DeliveryPolicy.php">Delivery Information</a>
                    <a href="contact.php">Contact Us</a>
                </div>
                <div class="col2">
                    <h4>My Account</h4>
                    <a href="signin.php">Sign in</a>
                    <?php         
            if(session_status() == PHP_SESSION_NONE){
                //session has not started
                session_start();
            }  
        if(isset($_SESSION["wp20user"]))
        { 
         echo '<a href="cart.php">View Cart</a>';
        } 
        else 
        { 
          echo '<a href="signin.php">View Cart</a>';
        } 
    ?>
                </div>
                
                <div class="col install">
                    <h4>Install App</h4>
                    <p>From AppStore or GooglePlay</p>
                    <div class="row">
                    <a href="https://apps.apple.com/today" ><img src="img/pay/app.jpg" alt=""></a>
                        <a href= "https://play.google.com/store/apps" ><img src="img/pay/play.jpg" alt=""></a>
                    </div>
                    <p>Secured Payements Gateways</p>
                    <img src="img/pay/pay.png" alt="">
                </div>
                
                <div class="copyright">
                <p>&copy; 2022 BestInTown | All Rights Reserved </p>
                </div>
        </footer>

    <script src="script.js"> </script>s

<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" ></script>  
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"> 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/cart.js"></script>
<link rel="stylesheet" href="styleLogin.css"> 
<link rel="stylesheet" href="style.css">
<script src="https://kit.fontawesome.com/e54aa46220.js" ></script>
</body>

</html>