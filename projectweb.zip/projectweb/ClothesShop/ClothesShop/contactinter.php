
<?php
// include_once 'contact.php';

// if( session_status() == PHP_SESSION_NONE)
// {
//     session_start();   
// }

//  function InsertContact($Name,$Email,$Title,$Mobile_Number,$Subject)
// { 
//     require_once('connection.php');

//     $res = false;
    
        // $sql = "Insert into messages (email,Phone_Number,Title,Message,username) 
        // values($Email,$Mobile_Number,$Title,$Subject,$Name)";
        // $result = mysqli_query($con,$sql);
        
//         $res=true;

//     return $res;
// }

// function AddContact($Name,$Email,$Mobile_Number,$Title,$Subject)
// {
   
//        if(InsertContact($Name,$Email,$Mobile_Number,$Title,$Subject))
//        {
//     return 0;
    
//        }
//        else 
//        { return 1;
       
// 	   }
 
//     }


// require_once('connection.php');
// if(isset($_POST['send']))
// {
//    $name = $_POST["name"];
//    $email = $_POST["email"];
//    $phonenumber = $_POST["mobileNumber"];
//    $title = $_POST["Title"];
//    $subject = $_POST["subject"];

//     $query = "Insert into messages(username,email,Phone_Number,Title,Message) values($name,$email,$phonenumber,$title,$subject)";
//     $run = mysqli_query($con,$query);

   
//     if($run)
//     {
//          echo "<script type='text/javascript'> 
//           alert('Message Received , ThankYou for your Visit!');
//        </script>"; 
//     }
//     else{
//         echo "<script type='text/javascript'> 
//         alert('Failed');
//      </script>"; 
        
//     }
   
   
// }
   
    //in case a field is empty we don't proceed
//      function validateContact ($name,$email,$phonenumber,$Title,$subject)
// {        
//     if(empty($name)|| empty($email) || empty($phonenumber) || empty($Title) || empty($subject) )
//     {
//         return false;
//     }
//     else
// 	{
//     return true;
// 	}
 
// }
    
    // if(!validateContact($name,$email,$phonenumber,$title,$subject))
    // {
    //     echo "<script> 
    //          alert('Invalid Submit , Please Re-check the form');
    //          </script>";
    // }
    // else
    //     if(addContact($name,$email,$phonenumber,$title,$subject)==0)
    //     { 
             
    //         echo "<script type='text/javascript'> 
    //         alert('Message Received , ThankYou for your Visit!');
    //    </script>";  
    //     }
		
// }
        
?>