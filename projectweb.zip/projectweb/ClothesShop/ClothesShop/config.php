
<?php
$con = mysqli_connect("localhost","root","","clothesshop");
if(!$con){
	die('Could not connect: ' . mysqli_error());
}
?>