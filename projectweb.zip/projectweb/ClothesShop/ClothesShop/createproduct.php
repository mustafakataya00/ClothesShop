<?php

// Include the config file to connect to the database
include "config.php";

// Check if the form has been submitted
if(isset($_POST['submit'])) {
    // Retrieve the form values
    $product_ID = $_POST['product_ID'];
    $Img_Path = $_POST['Img_Path'];
    $Price = $_POST['Price'];
    $Description = $_POST['Description'];
    $Brand = $_POST['Brand'];
    $Status = $_POST['Status'];
    $Category = $_POST['Category'];
    $gender = $_POST['gender'];
    
    // Check if a file was uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        // Set the target directory
        $target_dir = 'C:\wamp64\www\adminnn\folderpath';

        // Generate a unique file name
        $file_name = uniqid('image_', true) . '.' . pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);

        // Set the target path
        $target_path = $target_dir . $file_name;

        // Set the value of the Img_Path variable
        $Img_Path = $target_path;

        // Check if the file is an image
        $check = getimagesize($_FILES['image']['tmp_name']);
        if ($check !== false) {
            // Move the uploaded file to the target directory
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
                // File was uploaded successfully
                echo 'The image was uploaded successfully.';
            } else {
                // There was an error uploading the file
                echo 'There was an error uploading';
              }
            } else {
                // The uploaded file is not an image
                echo 'The uploaded file is not an image.';
            }
        } else {
            // No file was uploaded
            echo 'No image was selected.';
        }
    
        // Prepare the INSERT INTO statement with placeholders
        $stmt = $con->prepare("INSERT INTO products (product_ID, Img_Path, Price, Description, Brand, Status, Category, gender) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        // Bind the form values to the placeholders
        $stmt->bind_param("issssisi", $product_ID, $Img_Path, $Price, $Description, $Brand, $Status, $Category, $gender);
        // Execute the query
        $stmt->execute();
        
        // Check if the query was successful
        if ($stmt->affected_rows > 0) {
            // Redirect to the view page
            header('Location: view.php');
        } else {
            // Print an error message
            echo "Error: " . $stmt->error;
        }
        // Close the connection to the database
        $con->close();
    }
    ?>
    <!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Add Product</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
   <link rel="stylesheet" href="styleview.css"> 
   <link rel="stylesheet" href="stylecr.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!-- <a class="navbar-brand" href="#">Navbar</a> -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="view.php">Home <span class="sr-only"></span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Goto Website</a>
</li>
      <li class="nav-item">
        <a class="nav-link" href="create.php">Add User</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="createproduct.php">Add Product</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="viewproducts.php">view products</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Logout</a>
      </li>
    </ul>
  </div>
</nav>
<nav>
<form method="post" action="" enctype="multipart/form-data">
    <fieldset>
  <form>
  <label for="image">Choose an image:</label><br>
  <input type="file" id="image" name="Img_Path"><br>
  <label for="Price">Price:</label><br>
  <input type="text" id="Price" name="Price"><br>
  <label for="Description">Description:</label><br>
  <textarea id="Description" name="Description"></textarea><br>
  <label for="Brand">Brand:</label><br>
  <input type="text" id="Brand" name="Brand"><br>
  <label for="status">Status:</label><br>
  <input type="radio" id="status" name="Status" value="1" checked> Enable<br>
  <input type="radio" id="status" name="Status" value="0"> Disable<br>
  <label for="Category">Category:</label><br>
  <select id="Category" name="Category">
    <option value="Men">Men</option>
    <option value="Women">Women</option>
    <option value="Kids">Kids</option>
  </select>
  <br><br>
  <label for="gender">Gender:</label><br>
  <input type="radio" id="gender" name="gender" value="Male" checked> Male<br>
  <input type="radio" id="gender" name="gender" value="Female"> Female<br>
  <br><br>
  <input type="submit" value="Submit" name="submit">
  </form>
    </fieldset>
</form>
</nav>
</body>
</html>