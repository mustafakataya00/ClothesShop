<?php

include "config.php";

if(isset($_GET['product_ID'])) {
    $prod_id =$_GET['product_ID'];
    $sql = "DELETE from products where product_ID='$prod_id'";
    $result = $con->query($sql);


    if($result) {
        header('Location: viewproducts.php');
    } else {
        echo "Error: " . $stmt->error;
    }
}
echo mysqli_error($con);



?>
