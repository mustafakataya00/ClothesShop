<?php 
include("userregistration.php"); 

function Signup($username,$pass4 ,$email,$Phone_num) {

    if(create($username,$pass4,$email,$Phone_num))
    {
         return true;
    }
        
        return false; 
}

    ?>