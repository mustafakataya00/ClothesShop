<?php

// Check if the form was submitted
if (isset($_POST['submit'])) {
  // Check if a file was uploaded
  if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    // Set the target directory
    $target_dir = 'C:\wamp64\www\adminnn\folderpath';

    // Generate a unique file name
    $file_name = uniqid('image_', true) . '.' . pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);

    // Set the target path
    $target_path = $target_dir . $file_name;

    // Check if the file is an image
    $check = getimagesize($_FILES['image']['tmp_name']);
    if ($check !== false) {
      // Move the uploaded file to the target directory
      if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
        // File was uploaded successfully
        echo 'The image was uploaded successfully.';
      } else {
        // There was an error uploading the file
        echo 'There was an error uploading the image.';
      }
    } else {
      // The uploaded file is not an image
      echo 'The uploaded file is not an image.';
    }
  } else {
    // No file was uploaded
    echo 'No image was selected.';
  }
}

?>
