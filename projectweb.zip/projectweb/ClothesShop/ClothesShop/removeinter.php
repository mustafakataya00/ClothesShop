<?php 
session_start();
include ('CartManager.php');
$bool=Remove($_GET['id_product']) ; 
if ($bool==true ){ 
  header("Location: cart.php");
}
else echo "<script type='text/javascript'> 
alert('Album not removed');
</script>" ; 

?>