<?php

include "config.php";

if(isset($_GET['id'])) {
    $user_id =$_GET['id'];
    $sql = "DELETE from users where id='$user_id'";

    $result = $con->query($sql);

    if($result) {
        header('Location: view.php');
    } else {
        echo "Error: " . $stmt->error;
    }
}

?>
