<?php
session_start();
//Remove session
session_destroy();
setcookie("userAcc", "", time()-3600);
setcookie("userPass", "", time()-3600);
setcookie("adminAcc", "", time()-3600);
setcookie("adminPass", "", time()-3600);
header("Location:signin.php");
?>