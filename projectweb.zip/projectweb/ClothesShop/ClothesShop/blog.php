<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BestInTown</title>
    <script src="https://kit.fontawesome.com/e54aa46220.js" ></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
        <section id="header">
            
        <a href="user.php"><img src="img/logoBest.png" style="width:90px;height:70px"  class="logo" alt=""> </a>            
            <div>
                <ul id="navbar">
                    <li><a  href="user.php">Home</a></li>
                    <li><a href="shop.php">Shop</a></li>
                    <li><a class="active" href="blog.php">Blog</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <?php         
        if(session_status() == PHP_SESSION_NONE){
            //session has not started
            session_start();
        }  
    if(isset($_SESSION["wp20user"]))
    { 
    echo '<li><a href="cart.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
    echo' <li><a href="signout.php">Logout</a></li>' ;
    } 
    else 
    { 
   echo '<li><a href="signin.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
   echo '<li><a href="signin.php" ><i class="fa-solid fa-user"></i></a></li>' ;
    } 
?>
                </ul>
            </div>
          

        </section>

        <section id="page-header" class="blog-header">
            
            <h2>#Readmore</h2>
            
            <p>Read all case studies about our products</p>
        </section>

        <section id="blog">
            <div class="blog-box">
                <div class="blog-img">
                    <img src="img/blog/b1.jpg" alt="">
                </div>
                <div class="blog-details">
                    <h4> Lattest Articles in Fashion</h4>
                    <p>Lorem ipsumsed in maiores, reiciendis numquam tempore eligendi
                         enim tenetur iste id officiis  quasi nostrum.</p>
                    <a href="https://theconversation.com/global/topics/clothes-2991">CONTINUE READING</a>
                </div>
                <h1>13/01</h1>
            </div>
            <div class="blog-box">
                <div class="blog-img">
                    <img src="img/blog/b5.jpg" alt="">
                </div>
                <div class="blog-details">
                    <h4> The cotton-jersey Hoodie</h4>
                    <p>Lorem ipsumsed in maiores, reiciendis numquam tempore eligendi
                         enim tenetur iste id officiis  quasi nostrum.</p>
                    <a href="https://www.vogue.com/fashion">CONTINUE READING</a>
                </div>
                <h1>13/01</h1>
            </div>
            <div class="blog-box">
                <div class="blog-img">
                    <img src="img/blog/b2.jpg" alt="">
                </div>
                <div class="blog-details">
                    <h4> The cotton-jersey Hoodie</h4>
                    <p>Lorem ipsumsed in maiores, reiciendis numquam tempore eligendi
                         enim tenetur iste id officiis  quasi nostrum.</p>
                    <a href="https://www.nytimes.com/2022/10/10/style/clothes-wardrobe-need.html">CONTINUE READING</a>
                </div>
                <h1>13/01</h1>
            </div>
            <div class="blog-box">
                <div class="blog-img">
                    <img src="img/blog/b3.jpg" alt="">
                </div>
                <div class="blog-details">
                    <h4> The cotton-jersey Hoodie</h4>
                    <p>Lorem ipsumsed in maiores, reiciendis numquam tempore eligendi
                         enim tenetur iste id officiis  quasi nostrum.</p>
                    <a href="#">CONTINUE READING</a>
                </div>
                <h1>13/01</h1>
            </div>
            <div class="blog-box">
                <div class="blog-img">
                    <img src="img/blog/b4.jpg" alt="">
                </div>
                <div class="blog-details">
                    <h4> lattest Articles IN fashion </h4>
                    <p>Lorem ipsumsed in maiores, reiciendis numquam tempore eligendi
                         enim tenetur iste id officiis  quasi nostrum.</p>
                    <a href="https://fashionunited.com/news/fashion">CONTINUE READING</a>
                </div>
                <h1>13/01</h1>
            </div>
        </section>

        <section id="pagination" class="section-p1">
            <a href="#">1</a>
            <a href="#">2</a>
            <a href="#"><i class="fa-solid fa-arrow-right"></i></a>
        </section>

        <section id="newsletter" class="section-p1 section-m1">
            <div class="newstext">
                 <h4>Sign Up For Newsletters</h4>
                 <p>GetE-mail updates about our latest shop and<span> special offers.</span>
                 </p>
            </div>
            <form method="post" action='addEmailUpdates.php' style="width : 500px; height:20px;" class="form" >

<input type="email" name="email0" placeholder="Your email address">
<button  class="normal">Sign Up</button>

</form>
        </section>

        <footer class="section-p1">
            <div class="col">
    
                <p><strong>Address: </strong> Hadath,Near Consultation Council,Baabda </p>
                <p><strong>Phone: </strong> +961-76-935-846 / 05-464-073 </p>
                <p><strong>Working hours: </strong> 10:00 am - 10:00 pm,Mon - Sat  </p>
                <div class="follow">
                    <h4>Follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                    </div>
                </div>
            </div>
                 <div class="col1">
                    <a href="about.php">About us</a>
                    <a href="DeliveryPolicy.php">Delivery Information</a>
                    <a href="contact.php">Contact Us</a>
                </div>
                <div class="col2">
                    <h4>My Account</h4>
                    <a href="signin.php">Sign in</a>
                    <?php         
            if(session_status() == PHP_SESSION_NONE){
                //session has not started
                session_start();
            }  
        if(isset($_SESSION["wp20user"]))
        { 
         echo '<a href="cart.php">View Cart</a>';
        } 
        else 
        { 
          echo '<a href="signin.php">View Cart</a>';
        } 
    ?>
                </div>
                
                <div class="col install">
                    <h4>Install App</h4>
                    <p>From AppStore or GooglePlay</p>
                    <div class="row">
                    <a href="https://apps.apple.com/today" ><img src="img/pay/app.jpg" alt=""></a>
                        <a href= "https://play.google.com/store/apps" ><img src="img/pay/play.jpg" alt=""></a>
                    </div>
                    <p>Secured Payements Gateways</p>
                    <img src="img/pay/pay.png" alt="">
                </div>
                
                <div class="copyright">
                <p>&copy; 2022 BestInTown | All Rights Reserved </p>
                </div>
        </footer>

    <script src="script.js"> </script>
</body>
</html>   