 <?php 

 require_once('connection.php');
 if (isset($_COOKIE["userAcc"]) && isset($_COOKIE["userPass"])){
  
   if (isset($_COOKIE["adminAcc"]) && isset($_COOKIE["adminPass"])){
     setcookie("adminAcc", "", time()-3600);
     setcookie("adminPass", "", time()-3600);
   }
  
  $user = $_COOKIE["userAcc"];
  $pass = $_COOKIE["userPass"];
  $result = mysqli_query($con, "SELECT * from users WHERE username='$user' and password='$pass' ");

  if(mysqli_num_rows($result)==false){
     header("Location:signout.php");
  } else {
    if(session_status() == PHP_SESSION_NONE){
     //session has not started
      session_start();
     }
     $_SESSION["wp20user"] = $user . "user";
     $_SESSION["wp20userAcc"] = $user;
   }
}
  if (isset($_COOKIE["adminAcc"]) && isset($_COOKIE["adminPass"])){
  
  if (isset($_COOKIE["userAcc"]) && isset($_COOKIE["userPass"])){
    setcookie("userAcc", "", time()-3600);
    setcookie("userPass", "", time()-3600);
  }
  
  $user = $_COOKIE["adminAcc"];
  $pass = $_COOKIE["adminPass"];
  $result = mysqli_query($con, "SELECT * from users WHERE username='$user' and password='$pass' ");
  if(mysqli_num_rows($result)==false){
    header("Location:signout.php");
  } else {
    if(session_status() == PHP_SESSION_NONE)
    {
    {
      session_start();
    }
    $_SESSION["wp20admin"] = $user."user";
    $_SESSION["wp20adminAcc"] = $user;
  

}
  }
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BestInTown</title>
    <link rel="stylesheet" href="styleLogin.css"> 
     <link rel="stylesheet" href="style.css">  
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>

     
     <script src="https://kit.fontawesome.com/e54aa46220.js" ></script> 
     <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'> 
</head>
    <body>
 
    <?php //Start session
        if(session_status() == PHP_SESSION_NONE){
             //session has not started
             session_start();
        }
        // If the user session was already set, go to user.php
         if(isset($_SESSION["wp20user"])){
          header("Location:user.php");
         }
        //If the admin session was already set, go to admin.php
         if(isset($_SESSION["wp20admin"])){
          header("Location:admin.php");
          
         }
        //Show message if username or password are incorrect
         if(isset($_GET["error"]) && $_GET["error"] = 1){
           echo '<script>alert("Invalid Login Credentials")</script>';
         }
        ?>
        
        
     <section id="header">
            
     <a href="user.php"><img src="img/logoBest.png" style="width:90px;height:70px"  class="logo" alt=""> </a>            
            <div>
                <ul id="navbar">
                    <li><a href="user.php">Home</a></li>
                    <li><a href="shop.php">Shop</a></li>
                    <li><a href="blog.php">Blog</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <?php         
    if(session_status() == PHP_SESSION_NONE){
      //session has not started
      session_start();
  }
    if(isset($_SESSION["wp20user"]))
    { 
    echo '<li><a href="cart.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
    echo' <li><a class="active" href="signout.php">Logout</a></li>' ;
    } 
    else 
    { 
   echo '<li><a  href="signin.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
   echo '<li><a class="active" href="signin.php" ><i class="fa-solid fa-user"></i></a></li>' ;
    } 
?>
                </ul>
            </div>
</section>  

<section class="container forms"  style="background-color:white" >
            <div class="form login" style="margin-right:500px;">
                <div class="form-content" >
                    <header style="width:1000px;"> LoginForm</header>
                    <form method="post" action="signininter.php">
                    <div class="g-recaptcha" data-sitekey="6LfChIAjAAAAAChIOwkksxyK38_1gcI_--BltdkH"></div>

                    <div class="field input-field">
                    <input type="text" name="username" id="username" placeholder="Username" class="input" required>
                    </div>
                        
                    <div class="field input-field">
                            <input name="password" type="password" placeholder="Password" class="password">
                            <i class='bx bx-hide eye-icon'></i>
                        </div>

                    <div class="form-link" >
                      <label style="float:left;padding:5px;padding-bottom:10px;"><input type="checkbox" name="keepmeloggedin" id="keepmeloggedin" value="yes"> Remeber Me </label>
                      <a href="#" class="forgot-pass" style="float : right;">Forgot password?</a>
                    </div>

                    <div class="field button-field">
                    <input type="submit" name="submit" style="background-color : Blue ;color : white;" id="submit" value="Login">
                    </div>
                    

                    <div class="form-link" style="padding-top:30px;">
                        <span>Don't have an account? <a href="registre.php" >Signup</a></span>
                    </div>
                </div>

                <div class="line" style="margin-left:250px;width:500px;" ></div>

                  <div class="media-options" style="margin-left:250px;width:500px;">
                       <a href="https://www.google.com" class="field google">
                         <img src="img/google.png" alt="" class="google-img">
                         <span>Login with Google</span>
                        </a>
                   </div>
                    </form>
                   
            </div>

         
        </section>
        <footer class="section-p1">
            <div class="col">
    
                <p><strong>Address: </strong> Hadath,Near Consultation Council,Baabda </p>
                <p><strong>Phone: </strong> +961-76-935-846 / 05-464-073 </p>
                <p><strong>Working hours: </strong> 10:00 am - 10:00 pm,Mon - Sat  </p>
                <div class="follow">
                    <h4>Follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                    </div>
                </div>
            </div>
                 <div class="col1">
                    <a href="about.php">About us</a>
                    <a href="DeliveryPolicy.php">Delivery Information</a>
                    <a href="contact.php">Contact Us</a>
                </div>
                <div class="col2">
                    <h4>My Account</h4>
                    <a href="signin.php">Sign in</a>
                    <?php

// your secret key
$secret = "6LfChIAjAAAAAEO0N0yGc-1BLy5TIFsFXVLBt6LF";

// response received from the reCAPTCHA
$response = $_POST['g-recaptcha-response'];

// remote IP address of the user
$remoteip = $_SERVER['REMOTE_ADDR'];

// make a POST request to the Google reCAPTCHA server
$url = "https://www.google.com/recaptcha/api/siteverify";
$data = array(
"secret" => $secret,
"response" => $response,
"remoteip" => $remoteip
);
$options = array(
"http" => array(
"header" => "Content-type: application/x-www-form-urlencoded\r\n",
"method" => "POST",
"content" => http_build_query($data)
)
);
$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);

// check if the reCAPTCHA response was successful
if ($result === FALSE) {
// handle the error
// for example, show an error message to the user
echo "Sorry, there was a problem with the reCAPTCHA. Please try again.";
} else {
$result = json_decode($result);
if ($result->success) {
// the user successfully solved the reCAPTCHA
// proceed with form submission
// for example, insert the data into a database
} else {
// the user did not solve the reCAPTCHA
// show an error message to the user
echo "Sorry, the reCAPTCHA was not entered correctly. Please try again.";
}
}






?>
                    <?php         
            if(session_status() == PHP_SESSION_NONE){
                //session has not started
                session_start();
            }  
        if(isset($_SESSION["wp20user"]))
        { 
         echo '<a href="cart.php">View Cart</a>';
        } 
        else 
        { 
          echo '<a href="signin.php">View Cart</a>';
        } 
    ?>
                </div>
                
                <div class="col install">
                    <h4>Install App</h4>
                    <p>From AppStore or GooglePlay</p>
                    <div class="row">
                    <a href="https://apps.apple.com/today" ><img src="img/pay/app.jpg" alt=""></a>
                        <a href= "https://play.google.com/store/apps" ><img src="img/pay/play.jpg" alt=""></a>
                    </div>
                    <p>Secured Payements Gateways</p>
                    <img src="img/pay/pay.png" alt="">
                </div>
                
                <div class="copyright">
                <p>&copy; 2022 BestInTown | All Rights Reserved </p>
                </div>
        </footer>
        <script src= "script.js"></script>

  </body>
</html>
