<?php 
require_once('connection.php');
if(session_status() == PHP_SESSION_NONE)
{
  session_start();
}
include ('CartManager.php');


  $username = $_POST['username'];
  $id = $_POST['id'];
  $size = $_POST['size'];
  $quantity = $_POST['quantity'];

$bool=AddToCart($username,$id,$size,$quantity); 

if ($bool==true)
{ 

 header("Location:user.php");
}
else echo "<script type='text/javascript'> 
alert('Product not added');
</script>" ; 


?>