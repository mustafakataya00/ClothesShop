<?php

include ('CartRepo.php');

function AddToCart($username,$id_product,$size,$quantity)

    {
       if(InsertCart($id_product,$username,$size,$quantity))
       {
    return true;
    
       }
       else 
       { return false;
       
       }
    

    }
	function GetProducts($username)
	{
		 $result=Get($username);
      return $result ;
	}
		function GetOneId($id_product)
	{
		$result=GetOne($id_product);
		return $result;
	}
	
	function Remove($id_product)
	{
		$result=RemoveAlbum($id_product);
		return $result;
	}
	
	?>