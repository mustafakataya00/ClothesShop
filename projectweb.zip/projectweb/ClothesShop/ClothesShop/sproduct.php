<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BestInTown</title>
    <script src="https://kit.fontawesome.com/e54aa46220.js" ></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
        <section id="header">
            
        <a href="user.php"><img src="img/logoBest.png" style="width:90px;height:70px"  class="logo" alt=""> </a>            
            <div>
                <ul id="navbar">
                    
                    <li><a href="user.php">Home</a></li>
                    <li><a class="active" href="shop.php">Shop</a></li>
                    <li><a href="blog.php">Blog</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    
                    <?php         
        if(session_status() == PHP_SESSION_NONE){
            //session has not started
            session_start();
        }
    if(isset($_SESSION["wp20user"]))
    {
        echo '<li><a href="cart.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
        echo' <li><a href="signout.php">Logout</a></li>' ;
    } 
    else 
    { 
        echo '<li><a href="signin.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
        echo '<li><a href="signin.php"><i class="fa-solid fa-user"></i></a></li>' ;
    } 
?>
                </ul>
            </div>
          

        </section>

        <section id="prodetails" class="section-p1">
            
                <!-- <input type="submit" name="submit" value="Add To Cart" style="width:150px;background-color:#088178;font-size: 14px;font-weight: 600;padding: 15px 30px;border-radius: 12px;cursor: pointer;border: none;outline: none;transition: 0.2s;" > -->
                <?php
                require_once('connection.php');

               if(!isset($_SESSION['wp20user']))
               {
                header('Location:signin.php');
               }
               else
               {

               
                     if(isset($_GET['id']))
                    {

                        $id = $_GET['id'];
                        $username = $_SESSION['wp20user'];
                        $sql = "select * from products where product_ID = $id ";

                        $result = mysqli_query($con , $sql);
                        

                        while($row=mysqli_fetch_array($result))
                        {
                          
	                    
                            
                            $img_path = $row['Img_Path'];
                            $price = $row['Price'];
                            $description = $row['Description'];
                            $brand = $row['Brand'];
                            $cat = $row['Category'];

                            echo "<div class='single-pro-image'>
                            <img src=$img_path width='100%' id='MainImg'>
                            </div>
                         </div>
            
                        <form method='post' class='single-pro-details' action='addToCart.php' >
                            
                            <h6>Home/$cat</h6>
                            <h4>$description</h4>
                            <h7>$brand</h7>
                            <h2>$price $</h2>
                            <select name='size'>
                               <option>Select Size</option>
                                <option>Small</option>
                                <option>Medium</option>
                               <option>Large</option>
                                <option>X-Large</option>
                            </select>
                            <input type='number' name='quantity' value='1'>
                            <br>
                            <br> 
                            <input type='hidden' name='id' value=$id;>
                            <input type='hidden' name='username' value='$username';>
                            <input type='submit' name='submit' value='Add To Cart' style='width:150px;background-color:#088178;font-size: 14px;font-weight: 600;padding: 15px 30px;border-radius: 12px;cursor: pointer;border: none;outline: none;transition: 0.2s;';>";
    
                        }
                        }
                            
                        if(isset($_POST['submit']))
            {
                    
                    $selectedsize = $_POST['size'];
                    $quntity = $_POST['quantity'];
                    $pid = $_POST['id'];
                    $username = $_POST['username'];
                   

                ?>
                    <input type="hidden" name="size" value="<?php echo $selectedsize; ?>">
                    <input type="hidden" name="quantity" value="<?php echo $quntity; ?>">
                   
                <?php
            }
        }
        
        ?>
        </form>
        </section>
       
        


        <section id="product1" class="section-p1">
            <h2>Featured Products</h2>
            <p>Suggested Products</p>
            <div class="pro-container">
         
            <?php
                require_once('connection.php');
                    $sql3 = "select * from products where Category like'".$cat."'";
                    $result3 = mysqli_query($con,$sql3);
                    while($row3 = mysqli_fetch_array($result3))
                    {

                            $img_path = $row3['Img_Path'];
                            $price = $row3['Price'];
                            $description = $row3['Description'];
                            $brand = $row3['Brand'];
                            $ppid = $row3['product_ID'];

                        echo"
                        <div class='pro' onclick='window.location.href='sproduct.php';>
                        <a href='sproduct.php?id=$ppid' style='text-decoration:none'>
                        <img src= $img_path>  
                        <div class='des'>
                            <span>$brand</span>
                            <h5>$description</h5>
                            <h4>$price $</h4>   
                        </div>
                        <a href='#'><i class='fa fa-cart-shopping cart'></i></a>
                        </a>
                        </div> ";
                    }

            
            ?>
           
        

             
            
            
            </div>
        </section>

        <section id="newsletter" class="section-p1 section-m1">
            <div class="newstext">
                 <h4>Sign Up For Newsletters</h4>
                 <p>GetE-mail updates about our latest shop and<span> special offers.</span>
                 </p>
            </div>
            <form method="post" action='addEmailUpdates.php' style="width : 500px; height:20px;" class="form" >

                 <input type="email" name="email0" placeholder="Your email address">
                 <button  class="normal">Sign Up</button>

            </form>
        </section>

        <footer class="section-p1">
            <div class="col">
    
                <p><strong>Address: </strong> Hadath,Near Consultation Council,Baabda </p>
                <p><strong>Phone: </strong> +961-76-935-846 / 05-464-073 </p>
                <p><strong>Working hours: </strong> 10:00 am - 10:00 pm,Mon - Sat  </p>
                <div class="follow">
                    <h4>Follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                    </div>
                </div>
            </div>
                 <div class="col1">
                    <a href="about.php">About us</a>
                    <a href="DeliveryPolicy.php">Delivery Information</a>
                    <a href="contact.php">Contact Us</a>
                </div>
                <div class="col2">
                    <h4>My Account</h4>
                    <a href="signin.php">Sign in</a>
                    <?php         
            if(session_status() == PHP_SESSION_NONE){
                //session has not started
                session_start();
            }  
        if(isset($_SESSION["wp20user"]))
        { 
         echo '<a href="cart.php">View Cart</a>';
        } 
        else 
        { 
          echo '<a href="signin.php">View Cart</a>';
        } 
    ?>
                </div>
                
                <div class="col install">
                    <h4>Install App</h4>
                    <p>From AppStore or GooglePlay</p>
                    <div class="row">
                    <a href="https://apps.apple.com/today" ><img src="img/pay/app.jpg" alt=""></a>
                        <a href= "https://play.google.com/store/apps" ><img src="img/pay/play.jpg" alt=""></a>
                    </div>
                    <p>Secured Payements Gateways</p>
                    <img src="img/pay/pay.png" alt="">
                </div>
                
                <div class="copyright">
                <p>&copy; 2022 BestInTown | All Rights Reserved </p>
                </div>
        </footer>

        <script>
            var MainImg = document.getElementById("MainImg");
            var smallimg = document.getElementsByClassName("small-img");
           
            smallimg[0].onclick = function(){
                MainImg.src = smallimg[0].src
            }
            smallimg[1].onclick = function(){
                MainImg.src = smallimg[1].src
            }
            smallimg[2].onclick = function(){
                MainImg.src = smallimg[2].src
            }
            smallimg[3].onclick = function(){
                MainImg.src = smallimg[3].src
            }
        </script>


    <script src="script.js"> </script>
</body>
</html>   