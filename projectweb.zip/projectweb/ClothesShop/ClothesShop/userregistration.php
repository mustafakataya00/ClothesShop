<?php


function create($username,$pass4,$email,$Phone_num) {
    require_once('connection.php');

    $sql="INSERT INTO users(username,password,email,Level,Phone_num) VALUES
          ('". $username ."' , '". $pass4 ."',  '". $email ."' , '". 0 ."' , '". $Phone_num ."');" ;
    if (mysqli_query($con,$sql)) {
        header('Location: signin.php');
        return true;
    } 
    else {
        http_response_code(405);
        return false;
    }
    
    
}
?>
