 <?php
require_once('connection.php');
if(session_status() == PHP_SESSION_NONE){
    //session has not started
    session_start();
}  
  if(isset($_GET['check']))
  {
      if($_GET['check']==1)
      {
          $sql = "delete from cart where username ='".$_SESSION['wp20user']."'";
          if($con->query($sql)==false)
          {
            echo "<script language=javascript'> 
            alert('Unable do empty your cart'); 
            </script>"; 
          }
      }
      
  }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BestInTown</title>
    <script src="https://kit.fontawesome.com/e54aa46220.js" ></script>
    <link rel="stylesheet" href="style.css">
</head>

<body >
    <div >
        <section id="header">
            
            <a href="user.php"><img src="img/logoBest.png" style="width:90px;height:70px"  class="logo" alt=""> </a>
            
            <div>
                <ul id="navbar">
                    <li><a class="active" href="user.php">Home</a></li>
                    <li><a href="shop.php">Shop</a></li>
                    <li><a href="blog.php">Blog</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    
        <?php         
if(session_status() == PHP_SESSION_NONE){
    //session has not started
    session_start();
}  
    if(isset($_SESSION["wp20user"]))
    { 
    echo '<li><a href="cart.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
    echo' <li><a href="signout.php">Logout</a></li>' ;
    } 
    else 
    { 
   echo '<li><a href="signin.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
   echo '<li><a href="signin.php" ><i class="fa-solid fa-user"></i></a></li>' ;
    } 
?>
                </ul>
            </div>
          

        </section>

        

        <section id="hero">
            <h4>Trade-in-offer</h4>
            <h2>Super value deal</h2>
            <h1>On all products</h1>
            <p>Save more with coupons & up to 70%</p>
            <a href="shop.php" style="text-decoration: none; color:#088178 " ><button>Shop Now </button></a>
        </section>

        <section id="feature" class="section-p1">
            <div  class="fe-box">
                <img src="img/features/f1.png" alt="">
                <h6>Free shipping</h6>
            </div>
            <div  class="fe-box">
                <img src="img/features/f2.png" alt="">
                <h6>Online Order</h6>
            </div>
            <div  class="fe-box">
                <img src="img/features/f3.png" alt="">
                <h6>Save Money</h6>
            </div>
            <div  class="fe-box">
                <img src="img/features/f4.png" alt="">
                <h6>Promotions</h6>
            </div>
            <div  class="fe-box">
                <img src="img/features/f5.png" alt="">
                <h6>Happy Sell</h6>
            </div>
            <div  class="fe-box">
                <img src="img/features/f6.png" alt="">
                <h6>24/7 Support  </h6>
            </div>
        </section>
        
        <section id="product1" class="section-p1">
            <h2>Featured products</h2>
            <p>Summer collection New Modern Design</p>
            <div class='pro-container' >
            <?php
            require_once('connection.php');

            $sql = "select * from products WHERE Status = 'Enabled' LIMIT 8" ;
            $result = mysqli_query($con,$sql);
            while($row = mysqli_fetch_array($result))
            {
                $product_id = $row['product_ID'];
                $img_path = $row['Img_Path'];
                $price = $row['Price'];
                $description = $row['Description'];
                $brand = $row['Brand'];
                
                echo

                "<div class='pro'>
                <a href='sproduct.php?id=$product_id'  style='text-decoration:none'>
                <div class='pro'>
                        <img src= $img_path >  
                            <div class='des'>
                                 <span>$brand</span>
                                 <h5>$description</h5>

                                 <div class='star'>
                                    <i class='fa fa-star'></i>
                                    <i class='fa fa-star'></i>
                                    <i class='fa fa-star'></i>
                                    <i class='fa fa-star'></i>
                                    <i class='fa fa-star'></i>
                                 </div>
                                 <h4>$price $</h4>   
                            </div>
                       <i class='fa fa-cart-shopping cart'></i>
                    </div>
                    </a>
                    </div>
                    ";
                    
            }
        
            ?>
            </div>
        </section>

        <section id="banner" class="section-m1">
            <h4>Sales Services</h4>
            <h2>Up to <span>70% Off</span> - All t-shirts &Accessories </h2>
            <a href="shop.php" style ="text-decoration : none ; "> <button class="normal" style=" color :red">Explore More</button></a>
        </section> 

        <section id="product1" class="section-p1">
            <h2>New Arrivals</h2>
            <p>Winter collection </p>
            <div class="pro-container">
            <?php
            require_once('connection.php');

            $sql = "select * from products WHERE Status = 'Enabled' AND Category IN ('Winter','Fall')" ;
            $result = mysqli_query($con,$sql);
            while($row = mysqli_fetch_array($result))
            {
                $product_id = $row['product_ID'];
                $img_path = $row['Img_Path'];
                $price = $row['Price'];
                $description = $row['Description'];
                $brand = $row['Brand'];
                
                echo

                "<div class='pro'>
                <a href='sproduct.php?id=$product_id'  style='text-decoration:none'>
                <div class='pro'>
                        <img src= $img_path >  
                            <div class='des'>
                                 <span>$brand</span>
                                 <h5>$description</h5>

                                 <div class='star'>
                                    <i class='fa fa-star'></i>
                                    <i class='fa fa-star'></i>
                                    <i class='fa fa-star'></i>
                                    <i class='fa fa-star'></i>
                                    <i class='fa fa-star'></i>
                                 </div>
                                 <h4>$price $</h4>   
                            </div>
                       <i class='fa fa-cart-shopping cart'></i>
                    </div>
                    </a>
                    </div>
                    ";
                    
            }
        
            ?>
            </div>
        </section>

        <section id="sm-banner" class="section-p1">
            <div class="banner-box">
                <h4>crazy deals</h4>
                <h2>buy 1 get 1 free</h2>
                <span>The best classic dress is on sale </span>
                <button class="white">Learn More</button>
            </div>
            <div class="banner-box banner-box2">
                <h4>spring summer</h4>
                <h2>Upcoming Season</h2>
                <span>The best classic dress is on sale </span>
                <button class="white">Collection</button>
            </div>
        </section>
        <section id="banner3">
            <div class="banner-box">
                <h2>SEASONAL SALE</h2>
                <h3>Winter Collection -50% OFF</h3>
            </div>
            <div class="banner-box banner-box2">
                <h2>NEW FOOTWEAR COLLECTION</h2>
                <h3>Spring / Summer 2022</h3>
            </div>
             <div class="banner-box banner-box3">
                <h2>T-SHIRTS</h2>
                <h3>New Trendy Prints</h3>
            </div>
        </section>

        <section id="newsletter" class="section-p1 section-m1">
            <div class="newstext">
                 <h4>Sign Up For Newsletters</h4>
                 <p>Get E-mail updates about our latest shop and<span> special offers.</span>
                 </p>
            </div>
            <form method="post" action='addEmailUpdates.php' style="width : 500px; height:20px;" class="form" >

                 <input type="email" name="email0" placeholder="Your email address">
                 <button  class="normal">Sign Up</button>

            </form>
        </section>

        <footer class="section-p1">
            <div class="col">
    
                <p><strong>Address: </strong> Hadath,Near Consultation Council,Baabda </p>
                <p><strong>Phone: </strong> +961-76-935-846 / 05-464-073 </p>
                <p><strong>Working hours: </strong> 10:00 am - 10:00 pm,Mon - Sat  </p>
                <div class="follow">
                    <h4>Follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                    </div>
                </div>
            </div>
                 <div class="col1">
                    <a href="about.php">About us</a>
                    <a href="DeliveryPolicy.php">Delivery Information</a>
                    <a href="contact.php">Contact Us</a>
                </div>
                <div class="col2">
                    <h4>My Account</h4>
                    <a href="signin.php">Sign in</a>
                    <?php         
            if(session_status() == PHP_SESSION_NONE){
                //session has not started
                session_start();
            }  
        if(isset($_SESSION["wp20user"]))
        { 
         echo '<a href="cart.php">View Cart</a>';
        } 
        else 
        { 
          echo '<a href="signin.php">View Cart</a>';
        } 
    ?>
                </div>
                
                <div class="col install">
                    <h4>Install App</h4>
                    <p>From AppStore or GooglePlay</p>
                    <div class="row">
                    <a href="https://apps.apple.com/today" ><img src="img/pay/app.jpg" alt=""></a>
                        <a href= "https://play.google.com/store/apps" ><img src="img/pay/play.jpg" alt=""></a>
                    </div>
                    <p>Secured Payements Gateways</p>
                    <img src="img/pay/pay.png" alt="">
                </div>
                
                <div class="copyright">
                <p>&copy; 2022 BestInTown | All Rights Reserved </p>
                </div>
        </footer>
        

</div>
    <script src="script.js"> </script>
</body>
</html>   