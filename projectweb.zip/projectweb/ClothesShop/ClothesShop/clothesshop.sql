-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2022 at 02:33 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clothesshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `username` varchar(25) CHARACTER SET utf8 NOT NULL,
  `product_ID` int(11) NOT NULL,
  `size` varchar(20) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`username`, `product_ID`, `size`, `Quantity`) VALUES
('mostafa', 13, 'Small', 2),
('Alireda', 13, 'Medium', 1),
('ali', 6, 'Medium', 2);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `Emp_ID` int(30) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Role` varchar(50) NOT NULL,
  `Phone` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `img_path` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`Emp_ID`, `Name`, `Role`, `Phone`, `Email`, `img_path`) VALUES
(1, 'John Doe', 'Senior Marketing Manager', '+961 03 000 111', 'JoeContact@gmail.com', 'img/people/1.png'),
(2, 'William Smith', 'Senior Website Developer ', '+961 03 000 222', 'WilliamContact@gmail.com', 'img/people/2.png'),
(3, 'Emma Stone', 'Support Manager', '+961 03 000 333', 'EmmaContact@gmail.com', 'img/people/3.png');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`email`, `password`, `status`) VALUES
('mustafakataya123@icloud.com', '$2y$10$Lp.X1BQkEKzFki8eUiCZ7uWb1xNomf3LiZ5FI0aalwVOB1vZ7Yyu2', 0);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `Message_id` int(11) NOT NULL,
  `username` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(30) CHARACTER SET utf8 NOT NULL,
  `Phone_Number` varchar(30) CHARACTER SET utf8 NOT NULL,
  `Title` varchar(30) CHARACTER SET utf8 NOT NULL,
  `Message` varchar(1000) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`Message_id`, `username`, `email`, `Phone_Number`, `Title`, `Message`) VALUES
(1, 'Ali Reda', 'alireda@gmail.com', '70 001 110', 'Test', 'Hello Test Test'),
(2, 'Ali reda', 'AliReza@ua.edu.lb', '03777888', 'Testtt', 'Testtt Hello'),
(3, 'mostafa kataya', 'mustafakataya123@icloud.com', '76779380', 'Test', 'Hello '),
(4, 'hasan', 'hasan@hotmail.com', '03 002 000', 'any', 'message');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `user_id` int(11) NOT NULL,
  `email` varchar(40) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`user_id`, `email`) VALUES
(1, 'mustafakataya123@icloud.com'),
(3, 'hasanbaalbake@hotmail.com'),
(4, 'georgesabolooyoun@hotmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `email` varchar(25) CHARACTER SET utf8 NOT NULL,
  `address` varchar(100) NOT NULL,
  `Country` varchar(20) NOT NULL,
  `ZipCode` int(11) NOT NULL,
  `Total` float NOT NULL DEFAULT '0',
  `created_at` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`order_id`, `username`, `email`, `address`, `Country`, `ZipCode`, `Total`, `created_at`) VALUES
(23, 'mostafa', 'AliReda@ua.edu.lb', 'haretHreik Beirut', 'Turkey', 2002, 426, '2022-12-14 13:29:03'),
(24, 'ali', 'AliReda@ua.edu.lb', 'haretHreik Beirut', 'UK', 20222, 426, '2022-12-14 13:30:05'),
(25, 'Jawad', 'Jawad0@ua.edu.lb', 'Baabda', 'Lebanon', 2002, 246, '2022-12-14 13:31:03'),
(28, 'georges', 'georges@ua.edu.lb', 'Baabda', 'Germany', 232, 180, '2022-12-14 13:42:36');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_ID` int(11) NOT NULL,
  `Img_Path` varchar(100) CHARACTER SET utf8 NOT NULL,
  `Price` int(11) NOT NULL,
  `Description` varchar(500) CHARACTER SET utf8 NOT NULL,
  `Brand` varchar(20) CHARACTER SET utf8 NOT NULL,
  `Status` varchar(20) CHARACTER SET utf8 NOT NULL,
  `Category` varchar(25) NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_ID`, `Img_Path`, `Price`, `Description`, `Brand`, `Status`, `Category`, `gender`) VALUES
(1, 'img/products/f1.jpg', 78, 'Mix Colored Shirt', 'Zara', 'Enabled', 'Summer', 'Male'),
(2, 'img/products/f2.jpg', 78, 'Flowered Shirt', 'Zara', 'Enabled', 'Summer', 'Male'),
(3, 'img/products/f3.jpg', 78, 'Love Shirt', 'Zara', 'Enabled', 'Summer', 'Male'),
(4, 'img/products/f4.jpg', 78, 'White Pinky Shirt', 'Zara', 'Enabled', 'Summer', 'Male'),
(5, 'img/products/f5.jpg', 80, 'DarkBlue Shirt', 'H&M', 'Enabled', 'Summer', 'Male'),
(6, 'img/products/f6.jpg', 90, 'Life shirt', 'H&M', 'Enabled', 'Spring', 'Male'),
(7, 'img/products/n8.jpg', 110, 'Classy shirt', 'Boss', 'Enabled', 'Summer', 'Male'),
(8, 'img/products/f8.jpg', 70, 'Comfort shirt', 'H&M', 'Enabled', 'Summer', 'Male'),
(9, 'img/products/f7.jpg', 90, 'Comfort Flowered pant', 'H&M', 'Enabled', 'Summer', 'Female'),
(10, 'img/products/n1.jpg', 90, 'white shirt', 'bershka', 'Enabled', 'Fall', 'Male'),
(11, 'img/products/n2.jpg', 90, 'gray-white shirt', 'bershka', 'Enabled', 'Fall', 'Female'),
(12, 'img/products/n3.jpg', 90, 'ICE Shirt', 'H&M', 'Enabled', 'Fall', 'Female'),
(13, 'img/products/n4.jpg', 90, 'Military T-shirt', 'Maatouk', 'Enabled', 'Summer', 'Male'),
(14, 'img/products/n5.jpg', 110, 'Blue Shirt', 'H&M', 'Enabled', 'Winter', 'Male'),
(15, 'img/products/n6.jpg', 50, 'grey Short', 'H&M', 'Enabled', 'Summer', 'Male'),
(16, 'img/products/n7.jpg', 150, 'Classic shirt', 'H&M', 'Enabled', 'Winter', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `prop`
--

CREATE TABLE `prop` (
  `prop_id` int(11) NOT NULL,
  `product_ID` int(11) NOT NULL,
  `Size` varchar(10) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prop`
--

INSERT INTO `prop` (`prop_id`, `product_ID`, `Size`, `quantity`) VALUES
(1, 1, 'M', 20),
(2, 2, 'L', 15);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) CHARACTER SET utf8 NOT NULL,
  `password` varchar(150) CHARACTER SET utf8 NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `Level` int(11) NOT NULL,
  `Phone_num` varchar(30) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `Level`, `Phone_num`) VALUES
(9, 'Alireda', 'abHBwlTQSHgPwfe703d258c7ef5f50b71e06565a65aa07194907f', 'AliReda@ua.edu.lb', 0, '+96103 350 250'),
(7, 'user1', 'abTOJxeqm.Mjo63982e54a7aeb0d89910475ba6dbd3ca6dd4e5a1', 'user1@gmail.com', 0, '+961 03 123 321'),
(8, 'ali', 'abTOJxeqm.Mjo63982e54a7aeb0d89910475ba6dbd3ca6dd4e5a1', 'ali@ua.edu.lb', 0, '+961 03 321 321');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`Emp_ID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`Message_id`);

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_ID`);

--
-- Indexes for table `prop`
--
ALTER TABLE `prop`
  ADD PRIMARY KEY (`prop_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `Emp_ID` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `Message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `prop`
--
ALTER TABLE `prop`
  MODIFY `prop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
