<?php
require_once('connection.php');

if(!isset($_POST["username"]) || !isset($_POST["password"]))
{
	header("Location: signin.php");
}
else {
    $user = mysqli_real_escape_string($con, trim($_POST["username"]));
	$pass = mysqli_real_escape_string($con, trim($_POST["password"]));
	//Add MD5 password security
	$pass1 = md5($pass);
	//Add Additional security using sha1 hash of the password
	$pass2 = sha1($pass1);
	//Add encryption with salt
	$salt = "abcd";
	//Apply the encryption
	$pass3 = crypt($pass2,$salt);
	//Add more complexity to the encryption
	$pass4 = $pass3.$pass2;

    $result = mysqli_query($con, "SELECT * from users WHERE username='$user' and password='$pass4'");
	if(mysqli_num_rows($result)==false){
		header("Location:signin.php?error=1");
	} else {
		//If it exists, one row will be returned
		$row = mysqli_fetch_array($result);

		//Start a session
		session_start();
		//Check the level of the user and take it to the related page
        if($row["Level"] == 0){
			//Create a session for the user
			$_SESSION["wp20user"] = $row["username"];
			$_SESSION["wp20userAcc"] = $row["username"];
			//Set Cookie
			if($_POST["keepmeloggedin"]=="yes"){
				setcookie("userAcc", $row["username"], time()+31536000);
				setcookie("userPass", $row["password"], time()+31536000);
			}
			header("Location:user.php");
		} else {
			//Create a session for the admin
			$_SESSION["wp20admin"] = $row["username"];
			$_SESSION["wp20adminAcc"] = $row["username"];
			//Set Cookie
			if($_POST["keepmeloggedin"]=="yes"){
				setcookie("adminAcc", $row["username"], time()+31536000);
				setcookie("adminPass", $row["password"], time()+31536000);
			}
			header("Location:admin.php");
		}

}
}
?>