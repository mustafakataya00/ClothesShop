<?php 

require_once('connection.php');
if (isset($_COOKIE["userAcc"]) && isset($_COOKIE["userPass"])){
 
  if (isset($_COOKIE["adminAcc"]) && isset($_COOKIE["adminPass"])){
    setcookie("adminAcc", "", time()-3600);
    setcookie("adminPass", "", time()-3600);
  }
 
 $user = $_COOKIE["userAcc"];
 $pass = $_COOKIE["userPass"];
 $result = mysqli_query($con, "SELECT * from users WHERE username='$user' and password='$pass' ");

 if(mysqli_num_rows($result)==false){
    header("Location:signout.php");
 } else {
   if(session_status() == PHP_SESSION_NONE){
    //session has not started
     session_start();
    }
    $_SESSION["wp20user"] = $user . "user";
    $_SESSION["wp20userAcc"] = $user;
  }
}
 if (isset($_COOKIE["adminAcc"]) && isset($_COOKIE["adminPass"])){
 
 if (isset($_COOKIE["userAcc"]) && isset($_COOKIE["userPass"])){
   setcookie("userAcc", "", time()-3600);
   setcookie("userPass", "", time()-3600);
 }
 
 $user = $_COOKIE["adminAcc"];
 $pass = $_COOKIE["adminPass"];
 
 $result = mysqli_query($con, "SELECT * from users WHERE username='$user' and password='$pass' ");
 if(mysqli_num_rows($result)==false){
   header("Location:signout.php");
 } else {
   if(session_status() == PHP_SESSION_NONE)
   {
   {
     session_start();
   }
   $_SESSION["wp20admin"] = $user."user";
   $_SESSION["wp20adminAcc"] = $user;
 

}
 }
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>BestInTown</title>
   <link rel="stylesheet" href="styleLogin.css"> 
    <link rel="stylesheet" href="style.css">  
    
    <script src="https://kit.fontawesome.com/e54aa46220.js" ></script> 
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'> 
</head>
   <body>

   <?php //Start session
       if(session_status() == PHP_SESSION_NONE){
            //session has not started
            session_start();
       }
       // If the user session was already set, go to user.php
        if(isset($_SESSION["wp20user"])){
         header("Location:user.php");
        }
       //If the admin session was already set, go to admin.php
        if(isset($_SESSION["wp20admin"])){
          header("Location:admin.php");
        }
       //Show message if username or password are incorrect
        if(isset($_GET["error"]) && $_GET["error"] = 1){
          echo '<script>alert("Invalid Login Credentials")</script>';
        }
       ?>
       
       
    <section id="header">
           
           <a href="user.php"><img src="img/logo.png" class="logo" alt=""> </a>
           
           <div>
               <ul id="navbar">
                   <li><a href="user.php">Home</a></li>
                   <li><a href="shop.php">Shop</a></li>
                   <li><a href="blog.php">Blog</a></li>
                   <li><a href="about.php">About</a></li>
                   <li><a href="contact.php">Contact</a></li>
                   <?php         
   if(session_status() == PHP_SESSION_NONE){
     //session has not started
     session_start();
 }
   if(isset($_SESSION["wp20user"]))
   { 
   echo '<li><a href="cart.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
   echo' <li><a class="active" href="signout.php">Logout</a></li>' ;
   }
   else if(isset($_SESSION["wp20admin"]))
   { 
  
   } 
   else 
   { 
  echo '<li><a  href="signin.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
  echo '<li><a class="active" href="signin.php" ><i class="fa-solid fa-user"></i></a></li>' ;
   } 
?>
               </ul>
           </div>
</section>  

<section class="container forms"  style="background-color:white" >
           <div class="form login" style="margin-right:500px;">
               <div class="form-content" >
                   <header style="width:1000px;"> LoginForm</header>
                   <form method="post" action="signininter.php">
                   
                   <div class="field input-field">
                   <input type="text" name="username" id="username" placeholder="Username" class="input" required>
                   </div>
                       
                   <div class="field input-field">
                           <input name="password" type="password" placeholder="Password" class="password">
                           <i class='bx bx-hide eye-icon'></i>
                       </div>

                   <div class="form-link" >
                     <label style="float:left;padding:5px;padding-bottom:10px;"><input type="checkbox" name="keepmeloggedin" id="keepmeloggedin" value="yes"> Remeber Me </label>
                     <a href="#" class="forgot-pass" style="float : right;">Forgot password?</a>
                   </div>

                   <div class="field button-field">
                   <input type="submit" name="submit" style="background-color : Blue ;color : white;" id="submit" value="Login">
                   </div>
                   

                   <div class="form-link" style="padding-top:30px;">
                       <span>Don't have an account? <a href="#" class="link signup-link">Signup</a></span>
                   </div>
               </div>

               <div class="line" style="margin-left:250px;width:500px;" ></div>

                 <div class="media-options" style="margin-left:250px;width:500px;">
                      <a href="https://www.google.com" class="field google">
                        <img src="img/google.png" alt="" class="google-img">
                        <span>Login with Google</span>
                       </a>
                  </div>
                   </form>
                  
           </div>

        
       </section>

<footer class="section-p1" style="background-color:#E3E6F3;">
           <div class="col">
               <img src="img/logo.png" alt="">
               <h4>Contact</h4>
               <p><strong>Adresse: </strong> Hadath,Near Consultation Council,Baabda </p>
               <p><strong>Phone: </strong> +961-76-935-846 / 05-464-073 </p>
               <p><strong>Working hours: </strong> 10:00 am - 10:00 pm,Mon - Sat  </p>
               <div class="follow">
                   <h4>Follow us</h4>
                   <div class="icon">
                       <i class="fa-brands fa-facebook-f"></i>
                       <i class="fa-brands fa-twitter"></i>
                       <i class="fa-brands fa-instagram"></i>
                       <i class="fa-brands fa-youtube"></i>
                   </div>
               </div>
           </div>
                <div class="col1">
                   <h4>About</h4>
                   <a href="about.php">About us</a>
                   <a href="#">Delivery Information</a>
                   <a href="#">Privacy Policy</a>
                   <a href="#">Terms & Conditions</a>
                   <a href="contact.php">Contact Us</a>
               </div>
               <div class="col2">
                   <h4>My Account</h4>
                   <a href="signin.php">Sign in</a>
                   <a href="cart.php">View Cart</a>
                   <a href="#">My Wishlist</a>
                   <a href="#">Track my orders</a>
                   <a href="#">Help</a>
               </div>
               
               <div class="col install">
                   <h4>Install App</h4>
                   <p>From AppStore or GooglePlay</p>
                   <div class="row">
                       <img src="img/pay/app.jpg" alt="">
                       <img src="img/pay/play.jpg" alt="">
                   </div>
                   <p>Secured Payements Gateways</p>
                   <img src="img/pay/pay.png" alt="">
               </div>
               
               <div class="copyright">
               <p>&copy; 2022 BestInTown | All Rights Reserved </p>
               </div>
       </footer>
       <script src= "script.js"></script>
 </body>
</html>
