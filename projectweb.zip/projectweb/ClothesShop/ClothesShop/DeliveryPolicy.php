<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BestInTown</title>
    <script src="https://kit.fontawesome.com/e54aa46220.js" ></script>
    <link rel="stylesheet" href="style.css">
    <style>
#top{
	position:absolute;
	width:90%;
	margin-left:5%;
	margin-right:5%;
    margin-top:650px;
	padding:20px 0;
	text-align:center;
	
}
</style>
</head>
<body>
        <section id="header">
            
        <a href="user.php"><img src="img/logoBest.png" style="width:90px;height:70px"  class="logo" alt=""> </a>            
             <div>
                <ul id="navbar">
                    <li><a href="user.php">Home</a></li>
                    <li><a class="active" href="shop.php">Shop</a></li>
                    <li><a href="blog.php">Blog</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    
                    <?php         
            if(session_status() == PHP_SESSION_NONE){
                //session has not started
                session_start();
            } 
            if(isset($_SESSION["wp20user"]))
            { 
        echo '<li><a href="cart.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
        echo' <li><a href="signout.php">Logout</a></li>' ;
            } 
            else 
            { 
        echo '<li><a href="signin.php"><i class="fa-solid fa-bag-shopping"></i></a></li>';
        echo '<li><a href="signin.php" ><i class="fa-solid fa-user"></i></a></li>' ;
            } 
                    ?>

                </ul>
            </div>

        </section>


<b>
       <p> -    Our delivery service currently covers Lebanon based on the rules below:</p>
       <br>

<p> -    Items are delivered within 2-5 working days.</p>
<p> -    The delivery fees for Lebanon is 65,000 LBP, to be added to the total invoice amount.</p>
<p> -    If the address you provided wasn't the same as your real address, the delivery fees will be automatically adjusted based on the address we are delivering to.</p>
<p> -    Orders cannot be opened or tried by client upon delivery, and in case of any issue, kindly contact our support team at 76779380.</p>
<p> -    Your items will be delivered by SAKR EXPRESS, the delivery company we are currently dealing with.</p>
<p> -    After placing your order, you will receive an email that includes all order details, based on, your order will be proceed.</p>
        </p>
        </b>









        <section id="newsletter" class="section-p1 section-m1">
            <div class="newstext">
                 <h4>Sign Up For Newsletters</h4>
                 <p>GetE-mail updates about our latest shop and<span> special offers.</span>
                 </p>
            </div>
            <form method="post" action='addEmailUpdates.php' style="width : 500px; height:20px;" class="form" >

                 <input type="email" name="email0" placeholder="Your email address">
                 <button  class="normal">Sign Up</button>

            </form>
        </section>
        <footer class="section-p1">
            <div class="col">
    
                <p><strong>Address: </strong> Hadath,Near Consultation Council,Baabda </p>
                <p><strong>Phone: </strong> +961-76-935-846 / 05-464-073 </p>
                <p><strong>Working hours: </strong> 10:00 am - 10:00 pm,Mon - Sat  </p>
                <div class="follow">
                    <h4>Follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                    </div>
                </div>
            </div>
                 <div class="col1">
                    <a href="about.php">About us</a>
                    <a href="DeliveryPolicy.php">Delivery Information</a>
                    <a href="contact.php">Contact Us</a>
                </div>
                <div class="col2">
                    <h4>My Account</h4>
                    <a href="signin.php">Sign in</a>
                    <?php         
            if(session_status() == PHP_SESSION_NONE){
                //session has not started
                session_start();
            }  
        if(isset($_SESSION["wp20user"]))
        { 
         echo '<a href="cart.php">View Cart</a>';
        } 
        else 
        { 
          echo '<a href="signin.php">View Cart</a>';
        } 
    ?>
                </div>
                
                <div class="col install">
                    <h4>Install App</h4>
                    <p>From AppStore or GooglePlay</p>
                    <div class="row">
                    <a href="https://apps.apple.com/today" ><img src="img/pay/app.jpg" alt=""></a>
                        <a href= "https://play.google.com/store/apps" ><img src="img/pay/play.jpg" alt=""></a>
                    </div>
                    <p>Secured Payements Gateways</p>
                    <img src="img/pay/pay.png" alt="">
                </div>
                
                <div class="copyright">
                <p>&copy; 2022 BestInTown | All Rights Reserved </p>
                </div>
        </footer>
     
            
        </html>
